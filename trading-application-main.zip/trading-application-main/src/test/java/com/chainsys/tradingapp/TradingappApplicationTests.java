package com.chainsys.tradingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradingappApplicationTests {

	@Test
	void contextLoads() {
	}

}
